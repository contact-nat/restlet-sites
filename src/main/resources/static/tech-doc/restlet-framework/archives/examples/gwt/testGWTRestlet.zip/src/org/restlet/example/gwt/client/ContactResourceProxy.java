package org.restlet.example.gwt.client;

import org.restlet.client.resource.ClientProxy;
import org.restlet.client.resource.Get;
import org.restlet.client.resource.Result;

import common.Contact;

public interface ContactResourceProxy extends ClientProxy {

    @Get
    public void retrieve(Result<Contact> callback);

}